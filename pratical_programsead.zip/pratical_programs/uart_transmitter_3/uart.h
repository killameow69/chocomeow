#ifndef UART_H_
#define UART_H_

#include <stddef.h> // Include this for size_t
#include <termios.h>

#define BUFFER_SIZE 256

int set_interface_attribs(int fd, int speed);
int uart_open(const char *portname);
void uart_close(int fd);
int uart_write(int fd, const char *data);
int uart_read(int fd, unsigned char *buf, size_t buf_size);

#endif /* UART_H_ */

