#include <stdio.h>
#include <string.h>
#include "uart.h"

int main() {
    const char *portname = "/dev/ttyS3";
    int fd = uart_open(portname);
    if (fd < 0) {
        return -1;
    }

    if (set_interface_attribs(fd, B9600) < 0) {
        uart_close(fd);
        return -1;
    }

    char arr[BUFFER_SIZE];
    unsigned char buf[BUFFER_SIZE];

    while (1) {
        printf("Enter data (type 'exit' to quit): ");
        fgets(arr, sizeof(arr), stdin);

        // Remove newline character from input
        arr[strcspn(arr, "\n")] = '\0';

        if (strcmp(arr, "exit") == 0) {
            break;
        }

        if (uart_write(fd, arr) < 0) {
            uart_close(fd);
            return -1;
        }

        if (uart_read(fd, buf, sizeof(buf)) > 0) {
            printf("Received: %s\n", buf);
        }
    }

    uart_close(fd);
    return 0;
}

