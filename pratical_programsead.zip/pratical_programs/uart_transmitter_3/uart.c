#include "uart.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int set_interface_attribs(int fd, int speed) {
    struct termios tty;

    if (tcgetattr(fd, &tty) < 0) {
        printf("Error from tcgetattr: %s\n", strerror(errno));
        return -1;
    }

    cfsetispeed(&tty, (speed_t)speed);
    cfsetospeed(&tty, (speed_t)speed);

    tty.c_cflag |= (CLOCAL | CREAD);    /* ignore modem controls */
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;                 /* 8-bit characters */
    tty.c_cflag &= ~PARENB;             /* no parity bit */
    tty.c_cflag &= ~CSTOPB;             /* only need 1 stop bit */
    tty.c_cflag &= ~CRTSCTS;            /* no hardware flow control */

    tty.c_iflag = IGNPAR;
    tty.c_lflag = 0;

    tty.c_cc[VMIN] = 1;
    tty.c_cc[VTIME] = 1;

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        printf("Error from tcsetattr: %s\n", strerror(errno));
        return -1;
    }
    return 0;
}

int uart_open(const char *portname) {
    int fd = open(portname, O_RDWR | O_NOCTTY | O_SYNC);
    if (fd < 0) {
        printf("Error opening %s: %s\n", portname, strerror(errno));
    }
    return fd;
}

void uart_close(int fd) {
    close(fd);
}

int uart_write(int fd, const char *data) {
    int wlen = write(fd, data, strlen(data));
    if (wlen < 0) {
        printf("Error writing to UART: %s\n", strerror(errno));
        return -1;
    }
    usleep(10000); // Wait for 10 milliseconds for transmission to complete
    return wlen;
}

int uart_read(int fd, unsigned char *buf, size_t buf_size) {
    int rdlen = read(fd, buf, buf_size - 1);
    if (rdlen < 0) {
        printf("Error reading from UART: %s\n", strerror(errno));
        return -1;
    } else if (rdlen == 0) {
        printf("No data received\n");
        return 0;
    } else {
        buf[rdlen] = '\0'; // Null-terminate the received data
        return rdlen;
    }
}

