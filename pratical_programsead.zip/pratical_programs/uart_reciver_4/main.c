#include <stdio.h>
#include <string.h>
#include "uart_r.h"

int main() {
    const char *portname = "/dev/ttyS3";
    int fd = uart_open(portname);
    if (fd < 0) {
        return -1;
    }

    if (set_interface_attribs(fd, B9600) < 0) {
        uart_close(fd);
        return -1;
    }

    unsigned char rbuf[BUFFER_SIZE];

    while (1) {
        int rdlen = uart_read(fd, rbuf, sizeof(rbuf));
        if (rdlen > 0) {
            printf("Received: %s\n", rbuf);
        }
    }

    uart_close(fd);
    return 0;
}

