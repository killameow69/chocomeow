#ifndef UART_R_H_
#define UART_R_H_

#include <termios.h>
#include <stddef.h>  // Include this for size_t

#define BUFFER_SIZE 256

int set_interface_attribs(int fd, int speed);
int uart_open(const char *portname);
void uart_close(int fd);
int uart_read(int fd, unsigned char *buf, size_t buf_size);

#endif /* UART_R_H_ */

