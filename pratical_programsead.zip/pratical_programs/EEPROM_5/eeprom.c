#include "board_eeprom.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>

// I2C device path
static const char I2C_DEVICE[] = "/dev/i2c-0"; // Adjust this according to your setup
static const int EEPROM_ADDR = 0x50;            // EEPROM address

// Read board EEPROM
int ReadBoardEEPROM(cBoardEEPROM* boardEEPROM) {
    int fd;
    int result;

    if ((fd = open(I2C_DEVICE, O_RDWR)) < 0) {
        printf("Failed to open I2C device: %s\n", strerror(errno));
        return -1;
    }

    if (ioctl(fd, I2C_SLAVE, EEPROM_ADDR) < 0) {
        printf("Failed to acquire bus access and/or talk to slave: %s\n", strerror(errno));
        close(fd);
        return -1;
    }

    // Read from EEPROM
    result = read(fd, (void*)boardEEPROM, sizeof(cBoardEEPROM));
    if (result != sizeof(cBoardEEPROM)) {
        printf("Error reading from EEPROM: %s\n", strerror(errno));
        close(fd);
        return -1;
    }

    close(fd);
    return 0;
}

// Write board EEPROM
int WriteBoardEEPROM(cBoardEEPROM* boardEEPROM) {
    int fd;
    int result;

    if ((fd = open(I2C_DEVICE, O_RDWR)) < 0) {
        printf("Failed to open I2C device: %s\n", strerror(errno));
        return -1;
    }

    if (ioctl(fd, I2C_SLAVE, EEPROM_ADDR) < 0) {
        printf("Failed to acquire bus access and/or talk to slave: %s\n", strerror(errno));
        close(fd);
        return -1;
    }

    // Write to EEPROM
    result = write(fd, (void*)boardEEPROM, sizeof(cBoardEEPROM));
    if (result != sizeof(cBoardEEPROM)) {
        printf("Error writing to EEPROM: %s\n", strerror(errno));
        close(fd);
        return -1;
    }

    close(fd);
    return 0;
}

