#include <stdio.h>
#include <string.h>
#include "board_eeprom.h"

int main(int argc, char *argv[]) {
    int Result = 0;
    cBoardEEPROM board;

    strcpy(board.ModuleID, "RBEEPROM1234");
    strcpy(board.SerialNo, "112233445566");
    strcpy(board.data, "Phytec Embedded Pvt Ltd");

    WriteBoardEEPROM(&board);

    memset(&board, 0x00, sizeof(board));

    // Read EEPROM
    Result = ReadBoardEEPROM(&board);
    if (Result == 0) {
        printf("[EEPROM content]=============================\n");
        printf("Module ID : %s\n", board.ModuleID);
        printf("Serial NO : %s\n", board.SerialNo);
        printf("Data      : %s\n", board.data);
    }

    return 0;
}

