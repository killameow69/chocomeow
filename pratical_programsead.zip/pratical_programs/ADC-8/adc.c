#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>

#include "adc.h"

/* ADC - Initialization */
int adc_init(adc_config_t *adc_desc) {
    int mode_fd, capture_fd, length_fd;

    // Set ADC mode
    mode_fd = open("/sys/bus/iio/devices/iio:device0/in_conversion_mode", O_WRONLY);
    if (mode_fd < 0) {
        perror("open in_conversion_mode error");
        return -1;
    }
    if (write(mode_fd, adc_desc->adc_mode, strlen(adc_desc->adc_mode)) < 0) {
        perror("write in_conversion_mode error");
        close(mode_fd);
        return -1;
    }
    close(mode_fd);

    // Enable or disable buffer
    capture_fd = open("/sys/bus/iio/devices/iio:device0/buffer/enable", O_WRONLY);
    if (capture_fd < 0) {
        perror("open buffer enable error");
        return -1;
    }
    if (adc_desc->capture) {
        if (write(capture_fd, "1", 2) < 0) {
            perror("write buffer enable error");
            close(capture_fd);
            return -1;
        }
    } else {
        if (write(capture_fd, "0", 2) < 0) {
            perror("write buffer disable error");
            close(capture_fd);
            return -1;
        }
    }
    close(capture_fd);

    // Set buffer length
    length_fd = open("/sys/bus/iio/devices/iio:device0/buffer/length", O_WRONLY);
    if (length_fd < 0) {
        perror("open buffer length error");
        return -1;
    }
    snprintf(adc_desc->buf, sizeof(adc_desc->buff_length), "%d", adc_desc->buff_length);
    if (write(length_fd, adc_desc->buf, strlen(adc_desc->buf)) < 0) {
        perror("write buffer length error");
        close(length_fd);
        return -1;
    }
    close(length_fd);

    return 0;
}

/* ADC - SET CHANNEL */
int adc_set_channel(adc_config_t *adc_desc, int channel) {
    int channel_fd;
    sprintf(adc_desc->buf, "/sys/bus/iio/devices/iio:device0/scan_elements/in_voltage%d_en", channel);
    channel_fd = open(adc_desc->buf, O_WRONLY);
    if (channel_fd < 0) {
        perror("open scan_elements error");
        return -1;
    }
    if (write(channel_fd, "1", 2) < 0) {
        perror("write scan_elements error");
        close(channel_fd);
        return -1;
    }
    close(channel_fd);
    return 0;
}

/* ADC - READ OUTPUT DATA */
int adc_output(adc_config_t *adc_desc, int channel) {
    int output_fd, adc_data;
    char result[10];
    sprintf(adc_desc->buf, "/sys/bus/iio/devices/iio:device0/in_voltage%d_raw", channel);
    output_fd = open(adc_desc->buf, O_RDONLY);
    if (output_fd < 0) {
        perror("open in_voltage_raw error");
        return -1;
    }
    if (read(output_fd, result, sizeof(result)) < 0) {
        perror("read in_voltage_raw error");
        close(output_fd);
        return -1;
    }
    adc_data = atoi(result);
    close(output_fd);
    return adc_data;
}

