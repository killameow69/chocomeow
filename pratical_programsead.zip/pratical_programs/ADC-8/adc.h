#ifndef _ADC_H
#define _ADC_H

#define ONESHOT "oneshot"
#define CONTINUOUS "continuous"

// Define the structure adc_config_t with typedef
typedef struct {
    char *adc_mode;             // ADC mode - oneshot or continuous
    int capture;                // 1 - Enable buffer 0 - disable buffer
    unsigned int buff_length;   // buffer length
    int adc_channel;            // ADC channel to use (0-7)
    unsigned char buf[100];     // Buffer for ADC data
} adc_config_t;

// Function prototypes
int adc_init(adc_config_t *);
int adc_set_channel(adc_config_t *, int);
int adc_output(adc_config_t *, int);

#endif

