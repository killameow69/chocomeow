#include "switch.h"
#include <stdio.h>
int main()
{
	switches();
	return 0;
}
